# InfiniteRunner package

This is a package containing replica of a chrome dino game. You can play
[this game from here](https://github.com/Potceax/InfiniteRunner).

# Assets
Required assets and documentation can be downloaded from [here](). Assets should be placed in the /Src/ folder